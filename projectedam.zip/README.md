# ProjecteDam-TeamAME
Team project featuring Eloi, Miquel &amp; Arnau
